<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Sentinel;
use Session;
use Illuminate\Http\Request;


class UserController extends Controller
{
        public function usercheck()
       {
          $user = Sentinel::check();
           
            if($user->user_type == 'admin')
            {
                 $middelware = 'admin';
            }
           
        }

    public function dashboard()
    {
        $usercheck = $this->usercheck();

        return view(''.$usercheck.'/admin/dashboard')->with(compact('usercheck')); 
    }



    public function view_user()
       {

        $usercheck = $this->usercheck();

        if(isset($_GET['type']))
        {
            $type = $_GET['type'];
            $data = DB::table('users')
                    ->where('is_active','=',$type)
                    ->get();
        }
        else
        {
            $data = DB::table('users')
                    ->get();
        }
        
        return view(''.$usercheck.'/admin/view_user')->with(compact('data')); 
    } 


        public function is_active_status(Request $request)
            {

                $data['id']         = $request->input('id');
                $data['is_active']  = $request->input('is_active');

                  DB::table('users')
                      ->where('id','=',$data['id'])
                      ->update($data);


                Session::flash('success', 'User Activated Successfully');
                return redirect()->back();

            }

        
     public function user_edit()
       {

        {   

            $usercheck = $this->usercheck();
            $id     = $_GET['id'];
            $data   = DB::table('users')
                                ->where('id','=',$id)
                                ->first();
         

            return view(''.$usercheck.'/admin/user_edit')->with(compact('data','usercheck'));
    }
           
        }

        public function user_edit_post(Request $request)
        {
        //  print_r($request->input()); die();
            
            
            $data['email']                = $request->input('email');
            // $data['password']          = $request->input('password');
            $data['permissions']          = $request->input('permissions');
            $data['first_name']           = $request->input('first_name');
            $data['mobile']               = $request->input('mobile');
            $data['email1']               = $request->input('email1');
            $data['sponcer_id']           = $request->input('sponcer_id');
            $data['btc_address']          = $request->input('btc_address');
            $data['tron_address']         = $request->input('tron_address');
            $data['pan']                  = $request->input('pan');
            $data['adhar']                = $request->input('adhar');
            $data['bank_acc_no']          = $request->input('bank_acc_no');
            $data['bank_ifsc']            = $request->input('bank_ifsc');
            $data['bank_acc_holder_name'] = $request->input('bank_acc_holder_name');
            $data['city']                 = $request->input('city');
            $data['state']                = $request->input('state');
            $data['country']              = $request->input('country');
            $data['address']              = $request->input('address');
            $data['dob']                  = $request->input('dob');
            $data['is_active']            = $request->input('is_active');
            $data['user_type']            = $request->input('user_type');
              $id                           = $request->input('id');
               $data =   DB::table('users')
                                   ->where('id','=',$id)
                                   ->update($data);

            Session::flash('success', 'Employee Update Successfully');
            return redirect()->back();

     }

        public function view_details()
       {
            $usercheck = $this->usercheck();
            $id     = $_GET['id'];
            $data   = DB::table('users')
                                ->where('id','=',$id)
                                ->first();
         

            return view(''.$usercheck.'/admin/view_details')->with(compact('data','usercheck'));
    
           
        }

        public function set_password()
       {

        return view('admin/set_password');

         return view(''.$usercheck.'/admin/set_password')->with(compact('usercheck')); 
           
        }

        public function set_password_post(Request $request)
       {

        return view('admin/set_password_post');

         return view(''.$usercheck.'/admin/set_password_post')->with(compact('usercheck')); 
           
        }

        public function stop_withdraw(Request $request)
       {

                $data['id']         = $request->input('id');
                $data['withdrow_status']  = $request->input('withdrow_status');

                  DB::table('users')
                      ->where('id','=',$data['id'])
                      ->update($data);


                Session::flash('success', 'Status Change');
                return redirect()->back();
           
        }

        
         
         

         ///////////////////////////////////////////////////////////////////////////////////
        

         

        public function deposite_setting(Request $request)
       {

        return view('admin/deposite_setting');

         return view(''.$usercheck.'/admin/deposite_setting')->with(compact('usercheck')); 
           
        }

        public function registration_setting(Request $request)
       {

        return view('admin/registration_setting');

         return view(''.$usercheck.'/admin/registration_setting')->with(compact('usercheck')); 
           
        }



}
