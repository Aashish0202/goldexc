<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;

use Sentinel;
use Session;
use Illuminate\Http\Request;
use DB;


class SiteSettingController extends Controller
{ 
        public function usercheck()
       {
          $user = Sentinel::check();
           
            if($user->user_type == 'admin')
            {
                 $middelware = 'admin';
            }
           
        }  


      public function site_setting()
    {
         $usercheck = $this->usercheck();

          $data = DB::table('setting')
               ->first();
        return view(''.$usercheck.'/admin/site_setting')->with(compact('data','usercheck'));
    }

    public function site_setting_post(Request $request)
    {
        
        $data['site_name']       = $request->site_name; 
        $data['site_desc']       = $request->site_desc;
        
        $data['site_meta_key']   = $request->site_meta_key;
        $data['marquee']       = $request->marquee;


             if($request->has('site_logo')) {
              $file      = $request->file('site_logo');
              $extention = $file->getClientOriginalExtension();
              $filename  = time().'.'.$extention;
              $file->move(public_path('site_logo'),$filename);
              
              $data['site_logo']= $filename; 
             }
             
              
                $data = DB::table('setting')
                    ->update($data);
             return redirect()->back()->with('status','Image added successfully');        
                   
            return redirect()->back();
               
               
    }

        


     

}
