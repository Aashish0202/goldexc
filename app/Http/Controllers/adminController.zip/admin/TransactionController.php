<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;

use Sentinel;
use Session;
use Illuminate\Http\Request;
use DB;


class TransactionController extends Controller
{
     public function usercheck()
       {
          $user = Sentinel::check();
           
            if($user->user_type == 'admin')
            {
                 $middelware = 'admin';
            }
           
        }  
        
    public function status_change()
       {

        $usercheck = $this->usercheck();

        if(isset($_GET['type']))
        {
            $type = $_GET['type'];
            $data = DB::table('transaction')
                    ->where('approval','=',$type)
                    ->get();
        }
        else
        {
            $data = DB::table('transaction')
                    ->get();
        }
        
        return view(''.$usercheck.'/admin/status_change')->with(compact('data')); 
    } 

        public function status_change_data(Request $request)
       {

           $usercheck = $this->usercheck();
           
           $data['approval'] = $request->input('approval');

                   $data   = DB::table('transaction')
                                ->get();
                Session::flash('success', 'Transaction Approval Change');
                return redirect()->back();
                return view(''.$usercheck.'/admin/status_change')->with(compact('data','usercheck'));
           
        }



//// For Reson change

         public function sort_by_reason()
       {

        $usercheck = $this->usercheck();

        if(isset($_GET['type']))
        {
            $type = $_GET['type'];
            $data = DB::table('transaction')
                    ->where('reason','=',$type)
                    ->get();
        }
        else
        {
            $data = DB::table('transaction')
                    ->get();
        }
        
        return view(''.$usercheck.'/admin/sort_by_reason')->with(compact('data')); 
    } 

}
