 	<!-- Header -->
    @include('admin.common.header')

    <!-- Sidebar -->
    @include('admin.common.sidebar')


     @yield('content')


 	<!-- footer -->
    @include('admin.common.footer')

 