 

    @include('user.common.header')

   

    @include('user.common.sidebar')



    @yield('content')


   
    @include('user.common.footer')