  @include('admin.common.header ')
  <!-- Main Sidebar Container -->
 
      @include('admin.common.sidebar ')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>User</h1>
              </div>
<!--               <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active">DataTables</li>
                </ol>
              </div> -->
            </div>
          </div><!-- /.container-fluid -->
        </section>
  
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                  <table id="example2" class="table table-bordered table-hover">
                      <thead>
                      <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>First Name</th>
                        <th>City</th>
                        <th>Edit</th>
                        <th>View</th>
                        <th>Status</th>
                        <th>Set password</th>
                        <th>Stop widhdraw</th>
                        <th>Login As</th>
                      </tr>
                      </thead>
                      <tbody>
                          @foreach($data as $key=>$value)
                      <tr>
                          <td>{{$value->id}}</td>
                          <td>{{$value->email}}</td>
                          <td>{{$value->mobile}}</td>
                          <td>{{$value->first_name}}</td>
                          <td>{{$value->city}}</td>
                          <td><a href="{{url('/')}}/admin/user_edit?id={{$value->id}}" class="btn btn-warning">Edit</td>
                          <td><a href="{{url('/')}}/admin/view_details?id={{$value->id}}" class="btn btn-info">View</td>
                      <td>
                          <div class="btn-group">
                          <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              {{$value->is_active}}
                          </button>
                          <div class="dropdown-menu">
                              <a class="dropdown-item" href="{{url('/')}}/admin/is_active_status?id={{$value->id}}&is_active=active">Active</a>
                              <a class="dropdown-item" href="{{url('/')}}/admin/is_active_status?id={{$value->id}}&is_active=inactive">Inactive</a>
                              <a class="dropdown-item" href="{{url('/')}}/admin/is_active_status?id={{$value->id}}&is_active=block">Block</a>
                            </div>
                          </div>
                        </td>
                        <td ><a href="{{url('/')}}/admin/set_password?id={{$value->id}}" class="btn btn-info" style="padding: 3px;    line-height: 1.1;">Set Password</td>
                        
                        <td>
                          <div class="btn-group">
                          <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              {{$value->withdrow_status}}
                          </button>
                          <div class="dropdown-menu">
                              <a class="dropdown-item" href="{{url('/')}}/admin/stop_withdraw?id={{$value->id}}&withdrow_status=on">ON</a>
                              <a class="dropdown-item" href="{{url('/')}}/admin/stop_withdraw?id={{$value->id}}&withdrow_status=off">OFF</a>
                            </div>
                          </div>
                        </td>
                        <td><a href="" class="btn btn-info" style="padding: 3px;    line-height: 1.1;">Login as</td>
                      </tr>
                      @endforeach
                      </tbody>
                    
                  </table>
              </div>
            </div>
            <!-- /.card -->

           
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  @include('admin.common.footer')
