  @include('admin.common.header ')

  <!-- Main Sidebar Container -->
 
 
      @include('admin.common.sidebar ')

  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
             <!--  <div class="col-sm-6" style="margin-left:20%";>
                <h1>User Edit</h1>

              </div> -->
<!--               <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active">DataTables</li>
                </ol>
              </div> -->
            </div>
          </div><!-- /.container-fluid -->
        </section>
        <section>
          
          <div class="row">
            <div class="col-10">
               
              </div>
          </div>
        </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">

        <div class="row">
          <!-- left column -->
          <div class="col-md-12 mt-2" >
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">View User Details</h3>
                 <a href="{{url('/')}}/admin/user_edit?id={{$data->id}}"  class="btn btn-warning float-right my-4 ">Edit Users</a>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="{{url('/')}}/user_view" method="post" >
                 {{ csrf_field() }}
                <div class="card-body">
                  <div class="row">
                  <div class="form-group col-md-6">
                    <label for="email">Email : </label> {{$data->email}}
                   
                  
                  </div>
                  <div class="form-group col-md-6">
                    <label for="permission" id="permission" name="permission" >Permission :</label>{{$data->permissions}}
                   
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-6">
                    <label for="first_name" >Full Name : </label> {{$data->first_name}}
                  
                  </div>
                
                   <div class="form-group col-md-6">
                    <label for="mobile">Mobile : </label> {{$data->mobile}}
                    
                  </div>
                </div>
                <div class="row">
                   <div class="form-group col-md-6">
                    <label for="email1">Email1 : </label> {{$data->email1}}
                   
                  </div>
                  <div class="form-group col-md-6">
                    <label for="sponcer_id">Sponcer Id : </label> {{$data->sponcer_id}}
                   
                  </div>
                </div>
                <div class="row">
                   <div class="form-group col-md-6">
                    <label for="btc_address">BTC Address : </label> {{$data->btc_address}}
                    
                  </div>
                   <div class="form-group col-md-6">
                    <label for="tron_address">Tron Address : </label> {{$data->tron_address}}
                   
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-6">
                    <label for="pan">Pan Number : </label> {{$data->pan}}
                   
                  </div>
                   <div class="form-group col-md-6">
                    <label for="adhar">Aadhar Number : </label> {{$data->adhar}}
                   
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-6">
                    <label for="bank_acc_no">Bank Account Number : </label> {{$data->adhar}}
                   
                  </div>
                  <div class="form-group col-md-6">
                    <label for="bank_ifsc">Bank IFSC : </label> {{$data->adhar}}
                
                  </div>
                </div>
                <div class="row">
                   <div class="form-group col-md-6">
                    <label for="bank_acc_holder_name">Bank Account Holder Name : </label> {{$data->bank_acc_holder_name}}
                  
                  </div>
                  <div class="form-group col-md-6">
                    <label for="city">City : </label> {{$data->city}}
                 
                  </div>
                </div>
                <div class="row">
                 <div class="form-group col-md-6">
                    <label for="state">State : </label>  {{$data->state}}
                   
                  </div>
                   <div class="form-group col-md-6">
                    <label for="country">Country : </label> {{$data->country}}
                    
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-6">
                    <label for="address">Address</label>  {{$data->address}}
                    
                  </div>
                  
                   
                   <div class="form-group col-md-6">
                    <label for="dob">Date Of Birth : </label>  {{$data->dob}}
                   
                  </div>
                   </div>
                
                   <div class="row">
                   <div class="form-group col-md-6" >
                    <label for="is_active" >Is Active : </label>  {{$data->is_active}}
                   
               
                  </div>
                 <div class="form-group col-md-6" >
                    <label for="user_type" >User Type : </label> {{$data->user_type}}
                    
                  </div>
                </div>

              
              </form>
            </div>
        </div>
      
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

 @include('admin.common.footer')