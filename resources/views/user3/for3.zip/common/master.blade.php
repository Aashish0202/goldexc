 

    @include('user2.common.header')

   

    @include('user2.common.sidebar')



    @yield('content')


   
    @include('user2.common.footer')