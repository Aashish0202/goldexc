 <!-- Footer -->
            <footer class="footer container-fluid pl-30 pr-30">
                <div class="row">
                    <div class="col-sm-12">
                        <p><?php echo date('Y')?> &copy; soulusdt.com</p>
                    </div>
                </div>
            </footer>
            <!-- /Footer -->
            
        </div>
        <!-- /Main Content -->

    </div>
    <!-- /#wrapper -->
    
    <!-- JavaScript -->
    
    <!-- jQuery -->
    <script src="{{url('/')}}/new_theme/vendors/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    
    <!-- Data table JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    
    <!-- Slimscroll JavaScript -->
    <script src="{{url('/')}}/new_theme/doodle-demo/full-width-light/dist/js/jquery.slimscroll.js"></script>
    
    <!-- simpleWeather JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/bower_components/moment/min/moment.min.js"></script>
    <script src="{{url('/')}}/new_theme/vendors/bower_components/simpleWeather/jquery.simpleWeather.min.js"></script>
    <script src="{{url('/')}}/new_theme/doodle-demo/full-width-light/dist/js/simpleweather-data.js"></script>
    
    <!-- Progressbar Animation JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js"></script>
    <script src="{{url('/')}}/new_theme/vendors/bower_components/jquery.counterup/jquery.counterup.min.js"></script>
    
    <!-- Fancy Dropdown JS -->
    <script src="{{url('/')}}/new_theme/doodle-demo/full-width-light/dist/js/dropdown-bootstrap-extended.js"></script>
    
    <!-- Sparkline JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/jquery.sparkline/dist/jquery.sparkline.min.js"></script>
    
    <!-- Owl JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
    
    <!-- ChartJS JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/chart.js/Chart.min.js"></script>
    
    <!-- Morris Charts JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/bower_components/raphael/raphael.min.js"></script>
    <script src="{{url('/')}}/new_theme/vendors/bower_components/morris.js/morris.min.js"></script>
    <script src="{{url('/')}}/new_theme/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js"></script>
    
    <!-- Switchery JavaScript -->
    <script src="{{url('/')}}/new_theme/vendors/bower_components/switchery/dist/switchery.min.js"></script>
    
    <!-- Init JavaScript -->
    <script src="{{url('/')}}/new_theme/doodle-demo/full-width-light/dist/js/init.js"></script>
    <script src="{{url('/')}}/new_theme/doodle-demo/full-width-light/dist/js/dashboard-data.js"></script>
</body>


<!-- Mirrored from hencework.com/theme/doodle-demo/full-width-light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Jan 2022 11:14:15 GMT -->
</html>
